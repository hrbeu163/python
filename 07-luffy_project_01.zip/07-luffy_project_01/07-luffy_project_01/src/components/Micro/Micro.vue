<template>
	<div>
		我是学位课程
	</div>
</template>

<script>
export default {

  name: 'Micro',

  data() {
    return {

    };
  },
};
</script>

<style lang="css" scoped>
</style>
