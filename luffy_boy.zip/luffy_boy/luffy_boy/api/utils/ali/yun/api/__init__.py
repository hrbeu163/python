#! /usr/bin/env python
# -*- coding: utf-8 -*-
# Date: 2018/9/18


from .vod import AliYunVod
from .sms import AliYunSms
