#! /usr/bin/env python
# -*- coding: utf-8 -*-
# Date: 2018/9/18

"""
    阿里云相关服务, 目前提供支持：

        点播服务

        短信服务

"""
