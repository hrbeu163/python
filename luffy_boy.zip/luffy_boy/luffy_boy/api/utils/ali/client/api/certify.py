#! /usr/bin/env python
# -*- coding: utf-8 -*-
# Date: 2018/8/2

"""
    实名认证相关接口实现, 实名认证三步走

        认证初始化 > 开始认证 > 认证查询
"""


class AliCertification(object):
    pass
