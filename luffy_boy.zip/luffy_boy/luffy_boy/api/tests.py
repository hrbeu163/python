

# import redis


# r=redis.Redis(decode_responses=True)
#
# r.delete(*r.keys())

# print(r.keys())
# # print(r.get("1201812198500"))







